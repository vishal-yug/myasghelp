<?php

/**
 * @file
 * Default Plugin Class
 */

class BeanDefault extends BeanPlugin {}
